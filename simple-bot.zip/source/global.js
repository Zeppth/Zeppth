// folder: source

// globales
import path from 'path';
import fs from 'fs'

const settinsPath = path.resolve('./settings.json')
const BufferFile = fs.readFileSync(settinsPath)

global.readMore = String.fromCharCode(8206).repeat(850);
global.settings = JSON.parse(BufferFile)