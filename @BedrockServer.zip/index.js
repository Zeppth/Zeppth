import { ServerMinecraft } from "./makeServer.js";
import https from 'https'
import os from 'os'

const server = new ServerMinecraft({
    version: "1.21.51.02",
    properties: {
        "server-name": "Dedicated Server",
        "gamemode": "survival",
        "force-gamemode": false,
        "difficulty": "easy",
        "allow-cheats": true,
        "max-players": 20,
        "online-mode": true,
        "allow-list": false,
        "server-port": 19132,
        "server-portv6": 19133,
        "server-ip": "",
        "enable-lan-visibility": true,
        "view-distance": 32,
        "tick-distance": 4,
        "player-idle-timeout": 30,
        "max-threads": 8,
        "level-name": "Bedrock level",
        "level-seed": "",
        "default-player-permission-level": "member",
        "texturepack-required": false,
        "content-log-file-enabled": false,
        "compression-threshold": 1,
        "compression-algorithm": "zlib",
        "server-authoritative-movement": "server-auth",
        "player-position-acceptance-threshold": 0.5,
        "player-movement-action-direction-threshold": 0.85,
        "server-authoritative-block-breaking-pick-range-scalar": 1.5,
        "chat-restriction": "None",
        "disable-player-interaction": false,
        "client-side-chunk-generation-enabled": true,
        "block-network-ids-are-hashes": true,
        "disable-persona": false,
        "disable-custom-skins": false,
        "server-build-radius-ratio": "Disabled",
        "allow-outbound-script-debugging": false,
        "allow-inbound-script-debugging": false,
        "script-debugger-auto-attach": "disabled"
    }
});

server.on('close', data => console.log('Server closed:', data));
server.on('status', data => {
    if (data.status == 'downloading') {
        process.stdout.clearLine();
        process.stdout.cursorTo(0);
        process.stdout.write(`${data.message}`);
    } else {
        console.log(data.message)
    }
})
server.on('data', data => console.log(data));
server.on('error', data => console.error('Error:', data));

await server.start();

https.get('https://api.ipify.org?format=json', (response) => {
    let data = '';
    response.on('data', (chunk) => data += chunk);
    response.on('end', () => console.log('IP:', JSON.parse(data).ip));
}).on('error', (e) => console.log(e));

const networkInterfaces = os.networkInterfaces();
for (const interfaceName in networkInterfaces) {
    const networkInterface = networkInterfaces[interfaceName];
    for (const interfaceDetails of networkInterface) {
        if (interfaceDetails.family === 'IPv4' && !interfaceDetails.internal) {
            console.log('Mi IP local es:', interfaceDetails.address);
        }
    }
}
