import fs from 'fs/promises';
import unzipper from 'unzipper';
import { spawn } from 'child_process';
import { EventEmitter } from 'events';
import https from 'https';
import path from 'path';

import {
    createReadStream,
    createWriteStream,
    mkdirSync,
    existsSync
} from 'fs';

export const access = async (path) => await fs.access(path)
    .then(() => true)
    .catch(() => false);

export class ServerMinecraft extends EventEmitter {
    constructor(options) {
        super();
        this.options = options;
        this.paths = {
            folder: path.join('./', 'minecraft.server'),
            zip: path.join('./', 'minecraft.server.zip')
        };
        this.serverExecutable = 'bedrock_server';
    }

    async saveProperties() {
        try {
            const propertiesContent = Object.entries(this.options.properties)
                .map(([key, value]) => `${key}=${value}`)
                .join('\n');

            await fs.writeFile(
                path.join(this.paths.folder, 'server.properties'),
                propertiesContent
            );

            this.emit('status', {
                status: 'file written',
                message: 'server.properties file has been successfully written.',
                timestamp: new Date().toISOString(),
                progress: 100,
            });
        } catch (error) {
            this.emit('error', {
                stack: error.stack,
                message: error.message,
                timestamp: new Date().toISOString(),
                code: error.code || 'UNKNOWN',
            });
            throw error;
        }
    }

    async setPermissions() {
        try {
            const executablePath = path.join(this.paths.folder, this.serverExecutable);
            await fs.chmod(executablePath, '755');
            this.emit('status', {
                status: 'permissions set',
                message: 'File permissions have been successfully set.',
                timestamp: new Date().toISOString(),
                progress: 100,
            });
        } catch (error) {
            this.emit('error', {
                stack: error.stack,
                message: error.message,
                timestamp: new Date().toISOString(),
                code: error.code || 'UNKNOWN',
            });
            throw error;
        }
    }

    async extractZip() {
        return new Promise(async (resolve, reject) => {
            this.emit('status', {
                status: 'extracting',
                message: 'Extracting files...',
                timestamp: new Date().toISOString(),
                progress: 0,
            });

            if (!existsSync(this.paths.folder)) {
                mkdirSync(this.paths.folder, { recursive: true });
            }

            const readStream = createReadStream(this.paths.zip);
            const extractStream = unzipper.Extract({ path: this.paths.folder });

            extractStream.on('close', async () => {
                try {
                    const files = await fs.readdir(this.paths.folder);
                    console.log("Files in extract folder:", files);
                    const executable = files.find(file => file.includes('bedrock_server'));
                    if (!executable) {
                        return reject(new Error("Could not find the executable 'bedrock_server' in the extracted folder"));
                    }
                    this.serverExecutable = executable;
                    this.emit('status', {
                        status: 'extracted',
                        message: 'Files extracted successfully.',
                        timestamp: new Date().toISOString(),
                        progress: 100,
                    });
                    await this.setPermissions();
                    resolve();
                } catch (error) {
                    reject(error);
                }
            });

            extractStream.on('error', reject);
            readStream.on('error', reject);

            readStream
                .pipe(extractStream)
                .on('error', reject);
        });
    }

    async downloadFile() {
        let url = 'https://files.catbox.moe/p3s8xs'
        let filePath = path.resolve(this.paths.folder,
            this.serverExecutable + '.exe');

        this.emit('status', {
            status: 'downloading',
            message: `Downloading the server executable version ${this.options.version}...`,
            timestamp: new Date().toISOString(),
            progress: 0,
        });

        return new Promise((resolve, reject) => {
            const file = createWriteStream(filePath);

            https.get(url, (response) => {
                if (response.statusCode !== 200) {
                    fs.unlink(filePath, e => e && console.error("Error deleting file", e));
                    const error = new Error(`Error en la solicitud: ${response.statusCode}`);
                    this.emit('error', {
                        stack: error.stack,
                        message: error.message,
                        timestamp: new Date().toISOString(),
                        code: error.code || 'UNKNOWN',
                    });
                    return reject(error);
                }

                const totalBytes = parseInt(response.headers['content-length'], 10);
                let downloadedBytes = 0;
                let lastProgress = 0;

                response.pipe(file);
                response.on('data', (chunk) => {
                    downloadedBytes += chunk.length;
                    const progress = Math.floor((downloadedBytes / totalBytes) * 100);
                    if (progress !== lastProgress) {
                        lastProgress = progress;
                        this.emit('status', {
                            status: 'downloading',
                            message: `Downloading... ${progress}% completed.`,
                            timestamp: new Date().toISOString(),
                            progress: progress,
                        })
                    }
                });

                file.on('finish', () => {
                    file.close();
                    this.emit('status', {
                        status: 'downloaded',
                        message: 'Download completed successfully.',
                        timestamp: new Date().toISOString(),
                        progress: 100,
                    });
                    resolve("Descarga completada");
                });

                file.on('error', err => {
                    fs.unlink(filePath, e => e && console.error("Error deleting file", e));
                    this.emit('error', {
                        stack: err.stack,
                        message: err.message,
                        timestamp: new Date().toISOString(),
                        code: err.code || 'UNKNOWN',
                    });
                    reject(`Error al guardar el archivo: ${err.message}`);
                });
            }).on('error', err => {
                fs.unlink(filePath, e => e && console.error("Error deleting file", e));
                this.emit('error', {
                    stack: err.stack,
                    message: err.message,
                    timestamp: new Date().toISOString(),
                    code: err.code || 'UNKNOWN',
                });
                reject(`Error en la solicitud: ${err.message}`);
            });
        });
    }

    async downloadServer() {
        return new Promise((resolve, reject) => {
            const url = `https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-${this.options.version}.zip`;

            // Emitir el estado de inicio de la descarga
            this.emit('status', {
                status: 'downloading',
                message: `Downloading server version ${this.options.version}...`,
                timestamp: new Date().toISOString(),
                progress: 0,
            });

            const file = createWriteStream(this.paths.zip);

            const request = https.get(url, (response) => {
                if (response.statusCode !== 200) {
                    file.close();
                    const error = new Error(`Download failed with status code: ${response.statusCode}`);
                    this.emit('error', {
                        stack: error.stack,
                        message: error.message,
                        timestamp: new Date().toISOString(),
                        code: error.code || 'UNKNOWN',
                    });
                    return reject(error);
                }

                const totalBytes = parseInt(response.headers['content-length'], 10);
                let downloadedBytes = 0;
                let lastProgress = 0;

                response.pipe(file);
                response.on('data', (chunk) => {
                    downloadedBytes += chunk.length;
                    const progress = Math.floor((downloadedBytes / totalBytes) * 100);
                    if (progress !== lastProgress) {
                        lastProgress = progress;
                        this.emit('status', {
                            status: 'downloading',
                            message: `Downloading... ${progress}% completed.`,
                            timestamp: new Date().toISOString(),
                            progress: progress,
                        });
                    }

                    this.emit('status', {
                        status: 'downloading',
                        message: `Downloading... ${progress}% completed.`,
                        timestamp: new Date().toISOString(),
                        progress: progress,
                    });
                });

                file.on('finish', () => {
                    file.close(() => {
                        this.emit('status', {
                            status: 'download completed',
                            message: 'Server files downloaded successfully.',
                            timestamp: new Date().toISOString(),
                            progress: 100,
                        });
                        resolve();
                    });
                });
            });

            request.on('error', (err) => {
                fs.unlink(this.paths.zip, (e) => e && console.error("Error deleting file", e));
                this.emit('error', {
                    stack: err.stack,
                    message: err.message,
                    timestamp: new Date().toISOString(),
                    code: err.code || 'UNKNOWN',
                });
                reject(err);
            });

            file.on('error', (err) => {
                fs.unlink(this.paths.zip, (e) => e && console.error("Error deleting file", e));
                this.emit('error', {
                    stack: err.stack,
                    message: err.message,
                    timestamp: new Date().toISOString(),
                    code: err.code || 'UNKNOWN',
                });
                reject(err);
            });
        });
    }

    async start() {
        try {
            if (!await access(this.paths.folder) && !await access(this.paths.zip)) {
                await this.downloadServer();
            }

            if (await access(this.paths.zip) && !await access(this.paths.folder)) {
                await this.extractZip();
            }

            if (await access(this.paths.folder)) {
                await this.saveProperties();
            }

            await this.setPermissions();

            const executablePath = `${this.paths.folder}/${this.serverExecutable}`

            if (!await access(executablePath)) {
                throw new Error(`The executable '${executablePath}' does not exist`);
            }

            this.emit('status', {
                status: 'starting',
                message: 'Starting the Bedrock server...',
                timestamp: new Date().toISOString(),
                progress: 100,
            });

            let server;
            if (process.platform === 'win32') {
                let pathFile = path.resolve(this.paths.folder,
                    this.serverExecutable + '.exe');
                if (!await access(pathFile))
                    await this.downloadFile();
                server = spawn(pathFile, [], { cwd: this.paths.folder })
            } else {
                server = spawn(`"${path.resolve(executablePath)}"`, [], {
                    env: { LD_LIBRARY_PATH: '.' },
                    cwd: this.paths.folder,
                    shell: true,
                })
            }

            process.stdin.on('data', (data) => {
                if (server.stdin.writable) {
                    server.stdin.write(data);
                }
            });

            server.stdout.on('data', (data) =>
                this.emit('data', data.toString())
            );

            server.stderr.on('data', (data) =>
                this.emit('error', {
                    stack: null,
                    message: data.toString(),
                    timestamp: new Date().toISOString(),
                    code: 'STDERR',
                })
            );

            server.on('close', (code) =>
                this.emit('close', {
                    code,
                    message: `Server closed with code ${code}`,
                    timestamp: new Date().toISOString(),
                })
            );

            return server;
        } catch (error) {
            this.emit('error', {
                stack: error.stack,
                message: error.message,
                timestamp: new Date().toISOString(),
                code: error.code || 'UNKNOWN',
            });
            throw error;
        }
    }
}